import java.awt.*;
import java.util.ArrayList;

public class game {
    ArrayList<player> player_list = new ArrayList<player>();
    int current_Index = 0;
    pawn[] positions = new pawn[111];
    graph board = new graph();
    settings s; /* link this */
    /* constructor */
    game(String[] players){
        /* initializing positions list to null */
        for (pawn p: positions) {
            p = null;
        }
        /* setting initial positions to pawns */
        for (String player: players) {
            if(player.equals("")){
                /* if player name is blank then ignore*/
                continue;
            }else{
                /* create players and add their pawns to the start*/
                player temp_player = new player(player);
                player_list.add(temp_player);
                ArrayList<pawn> temp_pawn_list = temp_player.pawns;
                for (int i = 0; i < 5; i++) {
                    //sets location for every pawn
//                    temp_pawn_list.get(i).setPosition(0);
                    temp_pawn_list.get(i).reset();
                }
            }
        }
        int flag = 0;
        for (player p : player_list) {
            if (flag == 0) {
                p.set_default_pawn_position(2);
                for (pawn temp: p.pawns) {
                    temp.reset();
                }
            }
            if (flag == 1) {
                p.set_default_pawn_position(6);
                for (pawn temp: p.pawns) {
                    temp.reset();
                }
            }
            if (flag == 2) {
                p.set_default_pawn_position(10);
                for (pawn temp: p.pawns) {
                    temp.reset();
                }
            }
            if (flag == 3) {
                p.set_default_pawn_position(14);
                for (pawn temp: p.pawns) {
                    temp.reset();
                }
            }
            flag++;
        }

    }
    /* inserting move */
    int move(int button_index, int dice){
        pawn temp_pawn = find_pawn(button_index);
        int next_location = board.dfs(temp_pawn.getPosition(), dice);
        if (next_location == 0) return -1;
        /* checking if slot is empty*/
        if (positions[next_location] == null){
            positions[next_location] = temp_pawn;
        }else{
            positions[next_location].reset();//<- return to deafult
            positions[next_location] = temp_pawn;
        }
        temp_pawn.setPosition(next_location);
        current_Index++;
        return next_location;
    }

    player get_current_player(){
        return player_list.get(current_Index%(player_list.size()));
    }
    player next_current_player(){
        return player_list.get((current_Index)%(player_list.size()));
    }
    player next_player(){
        return player_list.get((current_Index)%(player_list.size()));
    }

    pawn find_pawn(int index){
        player temp_player = player_list.get(current_Index%(player_list.size()));
        pawn result = null;
        for (pawn p: temp_player.pawns) {
            if (p.getPosition() == index) {
                return p;
            }
        }
        return result;
    }

    /* method used to print for backend test */
    void print_pawn_locations(){
        System.out.println("=====================================");
        for ( player pl: player_list) {
            System.out.print(pl.getName()+"\t|\t");
            for (pawn p: pl.pawns) {
                System.out.print(p.position+"\t");
            }
            System.out.println();
        }
        System.out.println("=====================================");
    }

    /* testing code */
    public static void main(String[] args) {
        /* innitializing with names*/
        String[] list = {"Zian", "", "Harry", "", "John"};
        game g = new game(list);
//        System.out.println("lenght: "+g.player_list.size());
//        for ( player p: g.player_list) {
//            System.out.println(p.getName());
//        }
        /* setting color */
        g.player_list.get(0).setColor( new Color(0x5EBAFF));
//        System.out.println(g.player_list.get(0).getColor());
        /* setting default pawn position for pAlYER 0*/
        ArrayList<pawn> pawns2 = g.player_list.get(0).pawns;
        /* changing pawns positions */
        pawns2.get(3).setPosition(5);
        pawns2.get(0).setPosition(6);
//        for (int i = 0; i < 5; i++) {
//            System.out.println(pawns2.get(i).getPosition());
//        }
//        System.out.println("=============");
        g.print_pawn_locations();
        System.out.println(g.player_list.get(g.current_Index%(g.player_list.size())).getName());
        g.move(0,2);
        g.print_pawn_locations();
        System.out.println(g.player_list.get(g.current_Index%(g.player_list.size())).getName());
        g.move(0,3);
        g.print_pawn_locations();
        System.out.println(g.player_list.get(g.current_Index%(g.player_list.size())).getName());
        g.move(0,4);
        g.print_pawn_locations();
        System.out.println(g.player_list.get(g.current_Index%(g.player_list.size())).getName());
        g.move(6,2);
        g.print_pawn_locations();
        System.out.println(g.player_list.get(g.current_Index%(g.player_list.size())).getName());
        g.move(8,2);
        g.print_pawn_locations();
        g.move(9,1);
        g.print_pawn_locations();
        g.move(0,3);
        g.print_pawn_locations();
    }
}
