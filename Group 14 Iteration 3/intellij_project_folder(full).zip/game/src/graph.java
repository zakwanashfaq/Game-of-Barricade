/*
* Zakwan Ashfaq Zian
* 201950250
* */

import javax.swing.*;
import java.util.ArrayList;
/* Node model describing a single slot */
class node{
    int id;
    ArrayList <node> neighbour_list = new ArrayList<node>();
    boolean visited = false;
    boolean barricade = false;
    public node(int id) {
        this.id = id;
    }
    void visited(){
        this.visited = true;
    }
}

/* graph model describing the board */
public class graph {
    int dice;
    node[] slots = new node[66];

//    public void setButton_array(JButton[] button_array) {
//        this.button_array = button_array;
//    }
//
//    JButton[] button_array;
    public graph() {
        // initializing the slots
        for (int i=0; i<66; i++){
            slots[i] = new node(i);
        }
        initEdges();
    }
    /* initializes all relations - edges initialization */
    private void initEdges(){
        slots[2].neighbour_list.add(slots[3]);
        slots[2].neighbour_list.add(slots[1]);
        slots[1].neighbour_list.add(slots[0]);
        slots[3].neighbour_list.add(slots[4]);
        slots[4].neighbour_list.add(slots[18]);
        slots[0].neighbour_list.add(slots[17]);
        slots[17].neighbour_list.add(slots[22]);
        slots[22].neighbour_list.add(slots[23]);
        slots[23].neighbour_list.add(slots[24]);
        slots[18].neighbour_list.add(slots[26]);
        slots[26].neighbour_list.add(slots[25]);
        slots[25].neighbour_list.add(slots[24]);
        slots[26].neighbour_list.add(slots[27]);
        slots[24].neighbour_list.add(slots[39]);
        slots[39].neighbour_list.add(slots[43]);
        slots[43].neighbour_list.add(slots[44]);
        slots[44].neighbour_list.add(slots[45]);
        slots[6].neighbour_list.add(slots[5]);
        slots[5].neighbour_list.add(slots[4]);
        slots[6].neighbour_list.add(slots[7]);
        slots[7].neighbour_list.add(slots[8]);
        slots[8].neighbour_list.add(slots[19]);
        slots[19].neighbour_list.add(slots[30]);
        slots[30].neighbour_list.add(slots[29]);
        slots[29].neighbour_list.add(slots[28]);
        slots[28].neighbour_list.add(slots[40]);
        slots[27].neighbour_list.add(slots[28]);
        slots[10].neighbour_list.add(slots[9]);
        slots[9].neighbour_list.add(slots[8]);
        slots[10].neighbour_list.add(slots[11]);
        slots[30].neighbour_list.add(slots[31]);
        slots[31].neighbour_list.add(slots[32]);
        slots[32].neighbour_list.add(slots[41]);
        slots[11].neighbour_list.add(slots[12]);
        slots[12].neighbour_list.add(slots[20]);
        slots[20].neighbour_list.add(slots[34]);
        slots[34].neighbour_list.add(slots[33]);
        slots[33].neighbour_list.add(slots[32]);
        slots[32].neighbour_list.add(slots[41]);
        slots[40].neighbour_list.add(slots[47]);
        slots[41].neighbour_list.add(slots[51]);
        slots[34].neighbour_list.add(slots[35]);
        slots[35].neighbour_list.add(slots[36]);
        slots[36].neighbour_list.add(slots[42]);
        slots[15].neighbour_list.add(slots[16]);
        slots[14].neighbour_list.add(slots[13]);
        slots[13].neighbour_list.add(slots[12]);
        slots[14].neighbour_list.add(slots[15]);
        slots[38].neighbour_list.add(slots[37]);
        slots[16].neighbour_list.add(slots[21]);
        slots[21].neighbour_list.add(slots[38]);
        slots[37].neighbour_list.add(slots[36]);
        slots[36].neighbour_list.add(slots[42]);
        slots[42].neighbour_list.add(slots[55]);
    }

    int id;
    int dfs(int index, int dice){
        node start = slots[index];
        this.dice = dice;
        loop(start, 0);
        int temp = this.id;
        this.id = 0;
        return temp;
    }

    void loop(node n, int num) {
        if (n.barricade == true ) {
            if (dice == num) {
//                button_array[n.id].setEnabled(true);
                this.id = n.id;
            }
            return;
        }
        if (dice == num) {
//            button_array[n.id].setEnabled(true);
            this.id = n.id;
            return;
        }
        num++;
        for (int i = 0; i < n.neighbour_list.size(); i++) {
            loop(n.neighbour_list.get(i), num);
        }
    }

    /* testing code */
    public static void main(String[] args) {
        graph g = new graph();
        g.dfs(2, 3);
    }
}
